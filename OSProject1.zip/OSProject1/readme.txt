{\rtf1\ansi\ansicpg1252\cocoartf2636
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 This zip file contains the following files:\
\
1. CPU.java - Contains the CPU, which is the parent class of Memory\
2. Memory.java - Contains the Memory, which is the child class of CPU\
3. Summary - Discusses the purpose, implementation, and personal experience of the project\
4. Sample programs:\
	a. Sample1.txt - Prints A-Z 1-9\
	b. Sample2.txt - Prints a smiley face\
	c. Sample3.txt - Prints an incrementing value based on timer\
	d. Sample4.txt - Prints stack pointer after push and pops, as well as memory access failure\
	e. Sample5.txt - Prints hello world and the exponentiation of 2\
5. SampleOutputs.png - Contains a picture of the outputs of all the sample files running on cs3.utdallas.edu (running on java 1.8)\
\
This program can be compiled and run with the following commands:\
javac CPU.java Memory.java\
java CPU \{file\} \{timer\}\
Ex. java CPU sample1.txt 20\
See SampleOutputs to see it compile and run.}